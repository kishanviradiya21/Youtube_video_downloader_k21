//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"

#if __has_include(<flutter_youtube_downloader/FlutterYoutubeDownloaderPlugin.h>)
#import <flutter_youtube_downloader/FlutterYoutubeDownloaderPlugin.h>
#else
@import flutter_youtube_downloader;
#endif

#if __has_include(<webview_flutter/FLTWebViewFlutterPlugin.h>)
#import <webview_flutter/FLTWebViewFlutterPlugin.h>
#else
@import webview_flutter;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [FlutterYoutubeDownloaderPlugin registerWithRegistrar:[registry registrarForPlugin:@"FlutterYoutubeDownloaderPlugin"]];
  [FLTWebViewFlutterPlugin registerWithRegistrar:[registry registrarForPlugin:@"FLTWebViewFlutterPlugin"]];
}

@end
