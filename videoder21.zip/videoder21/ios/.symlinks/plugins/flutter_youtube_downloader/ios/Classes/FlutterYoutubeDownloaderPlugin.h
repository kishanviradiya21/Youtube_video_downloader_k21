#import <Flutter/Flutter.h>

@interface FlutterYoutubeDownloaderPlugin : NSObject<FlutterPlugin>
@end
