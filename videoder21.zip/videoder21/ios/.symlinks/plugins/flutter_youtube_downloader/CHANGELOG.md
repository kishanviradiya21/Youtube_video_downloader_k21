## 0.0.1

* A simple easy to use Flutter Youtube link extractor and downloader

## O.O.3

* Added instruction for extrating and downloading video on Android API 29+

## 0.0.4

* Fixed 'Download link is broken or not available for download' Error

## 0.0.5

* Migrated to Null Safety
