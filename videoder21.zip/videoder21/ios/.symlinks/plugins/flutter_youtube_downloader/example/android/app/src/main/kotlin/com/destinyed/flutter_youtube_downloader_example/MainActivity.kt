package com.destinyed.flutter_youtube_downloader_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
