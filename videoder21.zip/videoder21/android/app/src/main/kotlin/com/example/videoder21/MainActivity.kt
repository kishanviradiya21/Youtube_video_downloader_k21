package com.example.videoder21

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
