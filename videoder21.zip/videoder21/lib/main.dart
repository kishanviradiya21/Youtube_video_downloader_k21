import 'package:flutter/material.dart';
// import 'package:videoder21/pages/HomePage.dart';
import 'package:videoder21/pages/MainHomePage.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: MainPage(), // this is main , starting widget
  ));
}
